/*
Author       : Dreamstechnologies
Template Name: Smarthr - Bootstrap Admin Template
*/
(function () {
    "use strict";
	
	// Leave Settings
	$('.edit-leave-btn').on('click', function () {
		$(this).parent().parent().parent().toggleClass('show');
	});  
		
})();